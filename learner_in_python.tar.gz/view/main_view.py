# -*- coding: utf-8 -*-
__author__ = 'mcmushroom'

import sys
from PyQt4 import QtGui, QtCore, Qt


class MainWindow(QtGui.QWidget):

    def __init__(self):
        super(MainWindow, self).__init__()

        self.initUI()

    def initUI(self):

        logo = QtGui.QLabel(self)
        logo.resize(500, 250)
        logo.setPixmap(QtGui.QPixmap("image/logo_orange-black.jpg").scaled(logo.size(), QtCore.Qt.KeepAspectRatio))

        button = {}

        button["learn"] = QtGui.QPushButton('Nauka indywidualna', self)
        button["auto"] = QtGui.QPushButton('Nauka automatyczna', self)
        button["base"] = QtGui.QPushButton(u'bazy słówek', self)
        button["sets"] = QtGui.QPushButton('Ustawienia', self)
        button["close"] = QtGui.QPushButton(u'Wyjście', self)

        hbox = QtGui.QHBoxLayout()
        vbox = QtGui.QVBoxLayout()
        hbox_butt = QtGui.QHBoxLayout()
        vbox_butt = QtGui.QVBoxLayout()

        vbox_butt.addWidget(button["learn"])
        vbox_butt.addWidget(button["auto"])
        vbox_butt.addWidget(button["base"])
        vbox_butt.addWidget(button["sets"])
        vbox_butt.addWidget(button["close"])

        hbox_butt.addStretch(1)
        hbox_butt.addLayout(vbox_butt)
        hbox_butt.addStretch(1)

        vbox.addStretch(1)
        vbox.addWidget(logo)
        vbox.addStretch(1)
        vbox.addLayout(hbox_butt)
        vbox.addStretch(1)

        hbox.addStretch(1)
        hbox.addLayout(vbox)
        hbox.addStretch(1)

        self.setLayout(hbox)

        button["close"].clicked.connect(QtCore.QCoreApplication.instance().quit)

        self.resize(800, 600)
        self.center()
        self.setWindowTitle('Learner -- You just to learn_butt, and I will do the rest. ')
        self.setWindowIcon(QtGui.QIcon('image/app_ico.png'))
        self.show()

    def center(self):

        qr = self.frameGeometry()
        cp = QtGui.QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())